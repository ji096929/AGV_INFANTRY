/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef STEERING_WHEEL_BSP_H
#define STEERING_WHEEL_BSP_H

#ifdef __cplusplus
extern "C" {
#endif

/* Settings ------------------------------------------------------------------*/


/* Includes ------------------------------------------------------------------*/
#include <stdint.h>



#ifdef __cplusplus
}
#endif
#endif