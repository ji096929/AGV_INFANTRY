//
// Created by RM UI Designer
//

#ifndef UI_1_Ungroup_0_H
#define UI_1_Ungroup_0_H

#include "ui_interface.h"

extern ui_interface_line_t *ui_1_Ungroup_NewLine;

void _ui_init_1_Ungroup_0();
void _ui_update_1_Ungroup_0();
void _ui_remove_1_Ungroup_0();

#endif //UI_1_Ungroup_0_H
